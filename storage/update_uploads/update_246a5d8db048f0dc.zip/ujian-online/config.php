<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const DB_HOST = '127.0.0.1';
const DB_NAME = 'ujian_online';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );

        $pdo->exec("SET time_zone = '+07:00'");
    }
    return $pdo;
}

function app_base_path(): string {
    $script = str_replace('\\\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $pos = strpos($script, '/admin/');
    if ($pos === false) $pos = strpos($script, '/peserta/');
    if ($pos === false) {
        $dir = str_replace('\\\\', '/', dirname($script));
        return ($dir === '/' || $dir === '.' || $dir === '\\\\') ? '' : rtrim($dir, '/');
    }
    return substr($script, 0, $pos);
}


/**
 * Build a browser-reachable public base URL.
 * Priority: PUBLIC_BASE_URL environment/config -> current host -> LAN server IP when running on localhost.
 */
function public_base_url(): string {
    $configured = trim((string)(getenv('PUBLIC_BASE_URL') ?: ''));
    if ($configured !== '') return rtrim($configured, '/');

    $https = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    $hostOnly = preg_replace('/:\d+$/', '', $host) ?: $host;
    $port = '';
    if (preg_match('/:(\d+)$/', $host, $m)) $port=':'.$m[1];

    // localhost links cannot be opened from another device. Prefer the server LAN address.
    if ($hostOnly === '' || in_array(strtolower($hostOnly), ['localhost','127.0.0.1','::1'], true)) {
        $serverIp = trim((string)($_SERVER['SERVER_ADDR'] ?? ''));
        if ($serverIp !== '' && filter_var($serverIp, FILTER_VALIDATE_IP)
            && !in_array($serverIp, ['127.0.0.1','::1'], true)) {
            $host = $serverIp.$port;
        } elseif ($host === '') {
            $host = 'localhost';
        }
    }
    return $scheme.'://'.$host.rtrim(app_base_path(), '/');
}

function public_url(string $path=''): string {
    return rtrim(public_base_url(), '/').'/'.ltrim($path, '/');
}

function app_url(string $path=''): string {
    return app_base_path() . '/' . ltrim($path, '/');
}

function require_login(string $role): void {
    if (empty($_SESSION['user']) || ($_SESSION['user']['role'] ?? null) !== $role) {
        header('Location: ' . app_url('login.php'));
        exit;
    }
}

function json_response(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}


/**
 * Single source of truth for application version.
 */
function app_version(): string {
    static $version = null;
    if ($version !== null) return $version;
    $file = __DIR__ . '/VERSION.txt';
    $raw = is_file($file) ? trim((string)file_get_contents($file)) : '';
    $version = preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9._-]+)?$/', $raw) ? $raw : '0.0.0';
    return $version;
}

/**
 * Apply SQL migrations once. Safe to call repeatedly.
 * Each migration is identified by filename and SHA-256 checksum.
 */
function ensure_migrations(): array {
    static $done = false;
    if ($done) return [];
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
        version VARCHAR(64) PRIMARY KEY,
        checksum CHAR(64) NOT NULL,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $dir = __DIR__ . '/migrations';
    if (!is_dir($dir)) { $done = true; return []; }
    $files = glob($dir . '/*.sql') ?: [];
    usort($files, 'strnatcasecmp');
    $applied = [];
    foreach ($files as $file) {
        $version = basename($file, '.sql');
        $sql = trim((string)file_get_contents($file));
        $checksum = hash('sha256', $sql);
        $st = $pdo->prepare("SELECT checksum FROM schema_migrations WHERE version=?");
        $st->execute([$version]);
        $old = $st->fetchColumn();
        if ($old !== false) {
            if (!hash_equals((string)$old, $checksum)) {
                throw new RuntimeException("Migration checksum berubah: {$version}");
            }
            continue;
        }
        if ($sql !== '') {
            $pdo->beginTransaction();
            try {
                // Migration files in this project contain normal SQL statements.
                foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) as $statement) {
                    $statement = trim($statement);
                    if ($statement !== '') $pdo->exec($statement);
                }
                $pdo->prepare("INSERT INTO schema_migrations(version, checksum) VALUES(?,?)")
                    ->execute([$version, $checksum]);
                $pdo->commit();
                $applied[] = $version;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
        }
    }
    $done = true;
    return $applied;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('CSRF token tidak valid');
    }
}
