<?php
require __DIR__.'/../config.php'; require_login('admin');
$users=db()->query("SELECT id,full_name,username,participant_code,created_at FROM users WHERE role='participant' ORDER BY id DESC")->fetchAll();
?>
<!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Peserta</title>
<style>body{font-family:Inter,Arial;background:#f5f7fb;color:#17202a;margin:0}.top{background:#101828;color:#fff;padding:18px}.wrap{max-width:1100px;margin:auto;padding:22px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:22px;margin:14px 0}input{padding:11px;border:1px solid #d0d5dd;border-radius:9px;margin:4px;width:30%}button{padding:10px 15px;border:0;border-radius:9px;background:#175cd3;color:#fff;font-weight:700}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #eee;text-align:left}</style>
<div class="top"><div class="wrap" style="padding:0"><b>ExamFlow Admin</b><span style="float:right"><a style="color:white" href="index.php">Dashboard</a></span></div></div>
<div class="wrap"><div class="card"><h1>Peserta</h1><p>Tambah peserta satu per satu atau import CSV.</p>
<form method="post" action="save_participant.php"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input name="full_name" placeholder="Nama lengkap" required><input name="username" placeholder="Username/NIS" required><input name="participant_code" placeholder="Kode peserta"><input name="password" placeholder="Password awal" required><button>Tambah</button></form>
<hr><form method="post" action="import_participants.php" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input type="file" name="file" accept=".csv" required><button>Import CSV</button></form>
<p class="muted">Kolom: full_name, username, participant_code, password</p></div>
<div class="card"><h2>Daftar peserta</h2><table><tr><th>Nama</th><th>Username</th><th>Kode</th><th>Dibuat</th></tr><?php foreach($users as $u): ?><tr><td><?=htmlspecialchars($u['full_name'])?></td><td><?=htmlspecialchars($u['username'])?></td><td><?=htmlspecialchars($u['participant_code']??'')?></td><td><?=$u['created_at']?></td></tr><?php endforeach; ?></table></div></div></html>
