<?php
require __DIR__.'/../config.php';require_login('admin');check_csrf();
if(empty($_FILES['file']['tmp_name']))exit('File tidak ditemukan');
$h=fopen($_FILES['file']['tmp_name'],'r');$head=fgetcsv($h);$pdo=db();
while(($row=fgetcsv($h))!==false){$r=[];foreach($head as $i=>$k)$r[trim($k)]=$row[$i]??'';if(empty($r['username'])||empty($r['full_name']))continue;
$s=$pdo->prepare("INSERT INTO users(username,password_hash,role,participant_code,full_name) VALUES(?,?, 'participant',?,?) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),participant_code=VALUES(participant_code)");
$s->execute([$r['username'],password_hash($r['password']??'123456',PASSWORD_DEFAULT),$r['participant_code']??null,$r['full_name']]);
}
fclose($h);header('Location: participants.php');exit;
