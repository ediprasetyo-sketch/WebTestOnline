<?php
require __DIR__.'/../config.php';require_login('admin');check_csrf();
$s=db()->prepare("INSERT INTO users(username,password_hash,role,participant_code,full_name) VALUES(?,?, 'participant',?,?)");
$s->execute([trim($_POST['username']),password_hash($_POST['password'],PASSWORD_DEFAULT),trim($_POST['participant_code'])?:null,trim($_POST['full_name'])]);
header('Location: participants.php');exit;
