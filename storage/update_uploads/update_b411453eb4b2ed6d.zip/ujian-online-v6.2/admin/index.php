<?php
declare(strict_types=1);
require __DIR__.'/../config.php';
require_login('admin');

$pdo = db();
$exams = $pdo->query("
    SELECT e.*,
      (SELECT COUNT(*) FROM questions q WHERE q.exam_id=e.id) AS question_count,
      (SELECT COUNT(*) FROM attempts a WHERE a.exam_id=e.id) AS participant_count
    FROM exams e
    ORDER BY e.id DESC
")->fetchAll();

$totalExams = count($exams);
$activeExams = 0;
$totalQuestions = 0;
$totalAttempts = 0;
foreach ($exams as $e) {
    $activeExams += (int)$e['active'];
    $totalQuestions += (int)$e['question_count'];
    $totalAttempts += (int)$e['participant_count'];
}

$recentAttempts = [];
try {
    $recentAttempts = $pdo->query("
        SELECT a.id, a.started_at, a.status, e.title
        FROM attempts a
        JOIN exams e ON e.id=a.exam_id
        ORDER BY a.id DESC
        LIMIT 6
    ")->fetchAll();
} catch (Throwable $ignore) {
    $recentAttempts = [];
}

$msg = $_GET['msg'] ?? '';
$err = $_GET['err'] ?? '';

function dt_input(?string $v): string {
    return $v ? date('Y-m-d\TH:i', strtotime($v)) : '';
}
function exam_status(array $e): array {
    $now = time();
    $start = strtotime((string)$e['start_at']);
    $end = strtotime((string)$e['end_at']);
    if (!(int)$e['active']) return ['Nonaktif', 'off'];
    if ($now < $start) return ['Terjadwal', 'scheduled'];
    if ($now > $end) return ['Selesai', 'done'];
    return ['Aktif', 'on'];
}
?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard Admin</title><link rel="stylesheet" href="assets/admin-ui.css"></head>
<body><div class="admin-layout">
<aside class="admin-sidebar">
<div class="admin-brand"><span class="mark">✓</span> Ujian Online</div>
<div class="admin-section">MENU UTAMA</div>
<nav class="admin-nav">
<a class="active" href="index.php"><span class="ico">⌂</span>Dashboard</a>
<a href="index.php"><span class="ico">▣</span>Ujian</a>
<a href="participants.php"><span class="ico">♟</span>Peserta</a>
<a href="templates.php"><span class="ico">⇩</span>Template Import Soal</a>
</nav>
<div class="admin-section">SISTEM</div>
<nav class="admin-nav"><a href="update.php"><span class="ico">☁</span>Update Sistem</a></nav>
<div class="system-box"><h4>Informasi Sistem</h4>
<div class="system-row"><span>Versi Aplikasi</span><span class="version-chip"><?=htmlspecialchars(trim(@file_get_contents(__DIR__.'/../VERSION.txt')) ?: '6.3.21')?></span></div>
<div class="system-row"><span>PHP Version</span><b><?=htmlspecialchars(PHP_VERSION)?></b></div>
<div class="system-row"><span>Server</span><b><?=htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'PHP')?></b></div>
<div class="system-row"><span>Environment</span><span class="prod-chip">Production</span></div>
</div></aside>

<main class="admin-main">
<header class="admin-topbar"><div class="top-left"><span class="hamb">☰</span><h1>Dashboard Admin</h1></div><div class="profile"><span>◔</span><div class="avatar">A</div><div><b>Administrator</b><div class="ui-sub">Super Admin</div></div><span>⌄</span></div></header>
<div class="admin-content">
<div class="page-head"><div><h2 class="page-title">Dashboard Administrator</h2><p class="page-subtitle">Selamat datang kembali, Administrator! Kelola ujian online, peserta, dan hasil dengan mudah.</p></div><div class="crumb">⌂ Beranda &nbsp;/&nbsp; Dashboard</div></div>

<section class="ui-grid stats-grid">
<div class="ui-card stat-card"><div class="stat-body"><div class="stat-icon">▣</div><div><div class="ui-label">TOTAL UJIAN</div><div class="ui-value">0</div><div class="ui-sub">Semua ujian tersimpan</div></div></div><div class="stat-link">Lihat semua ujian &nbsp;→</div></div>
<div class="ui-card stat-card green"><div class="stat-body"><div class="stat-icon">♟</div><div><div class="ui-label">PESERTA TERDAFTAR</div><div class="ui-value">0</div><div class="ui-sub">Total peserta terdaftar</div></div></div><div class="stat-link" style="color:#1d9b62">Lihat semua peserta &nbsp;→</div></div>
<div class="ui-card stat-card orange"><div class="stat-body"><div class="stat-icon">▤</div><div><div class="ui-label">TOTAL SOAL</div><div class="ui-value">0</div><div class="ui-sub">Semua soal tersedia</div></div></div><div class="stat-link" style="color:#ed8a12">Kelola soal &nbsp;→</div></div>
<div class="ui-card stat-card purple"><div class="stat-body"><div class="stat-icon">▥</div><div><div class="ui-label">ATTEMPT HARI INI</div><div class="ui-value">0</div><div class="ui-sub">Percobaan hari ini</div></div></div><div class="stat-link" style="color:#7147c9">Lihat laporan &nbsp;→</div></div>
</section>

<section class="ui-grid content-grid">
<div class="ui-card card-pad"><h3 class="card-title">Ringkasan Aktivitas <select style="float:right;padding:8px;border:1px solid var(--line);border-radius:7px;color:#53657c"><option>7 Hari Terakhir</option></select></h3><div class="legend"><span><i class="dot" style="background:#2f66c9"></i>Ujian Dibuat</span><span><i class="dot" style="background:#1d9b62"></i>Percobaan</span></div><div class="chart"><svg viewBox="0 0 800 240" preserveAspectRatio="none"><path d="M10 210 L145 210 L280 210 L415 210" fill="none" stroke="#2f66c9" stroke-width="2"/><path d="M415 210 L550 210 L685 210 L790 210" fill="none" stroke="#1d9b62" stroke-width="2"/><g fill="#fff" stroke="#2f66c9" stroke-width="3"><circle cx="10" cy="210" r="4"/><circle cx="145" cy="210" r="4"/><circle cx="280" cy="210" r="4"/></g><g fill="#fff" stroke="#1d9b62" stroke-width="3"><circle cx="415" cy="210" r="4"/><circle cx="550" cy="210" r="4"/><circle cx="685" cy="210" r="4"/><circle cx="790" cy="210" r="4"/></g></svg></div></div>
<div class="ui-card card-pad"><h3 class="card-title">Akses Cepat</h3><div class="quick-grid">
<a class="quick" href="index.php"><span class="qicon blue">⊕</span>Buat Ujian Baru</a>
<a class="quick" href="participants.php"><span class="qicon green-t">♟</span>Kelola Peserta</a>
<a class="quick" href="index.php"><span class="qicon orange-t">▤</span>Kelola Soal</a>
<a class="quick" href="index.php"><span class="qicon purple-t">◔</span>Lihat Hasil</a>
<a class="quick" href="templates.php"><span class="qicon blue">☁</span>Import Soal</a>
<a class="quick" href="update.php"><span class="qicon danger-t">☁</span>Update Sistem</a>
</div></div></section>

<section class="ui-grid bottom-grid">
<div class="ui-card card-pad"><a class="section-link" href="index.php">Lihat Semua →</a><h3 class="card-title">Ujian Terbaru</h3><div class="empty"><span class="info-i">i</span><div><b>Belum ada data ujian.</b><br><span class="ui-sub">Silakan buat ujian baru untuk memulai.</span></div></div></div>
<div class="ui-card card-pad"><a class="section-link" href="index.php">Lihat Semua →</a><h3 class="card-title">Aktivitas Terbaru</h3><div class="empty"><span class="info-i">i</span><div><b>Belum ada aktivitas.</b><br><span class="ui-sub">Aktivitas sistem akan muncul di sini.</span></div></div></div>
</section>
</div><footer class="admin-footer"><span>© <?=date('Y')?> Ujian Online. All rights reserved.</span><span>Versi <?=htmlspecialchars(trim(@file_get_contents(__DIR__.'/../VERSION.txt')) ?: '6.3.21')?></span></footer>
</main></div></body></html>