<?php
require_once __DIR__ . '/../config.php';
require_login('admin');

const APP_VERSION = '6.3.20';
$root = realpath(__DIR__ . '/..');
$backupDir = $root . '/storage/backups';
$uploadDir = $root . '/storage/update_uploads';
$stagingRoot = $root . '/storage/update_staging';
@mkdir($backupDir, 0775, true);
@mkdir($uploadDir, 0775, true);
@mkdir($stagingRoot, 0775, true);

function rrmdir($dir) {
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
    @rmdir($dir);
}
function safe_zip_extract($zipFile, $target) {
    $zip = new ZipArchive();
    if ($zip->open($zipFile) !== true) throw new RuntimeException('File ZIP tidak dapat dibuka.');
    if ($zip->numFiles > 5000) throw new RuntimeException('Paket update terlalu banyak file.');
    $total = 0;
    for ($i=0; $i<$zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        $stat = $zip->statIndex($i);
        $total += (int)($stat['size'] ?? 0);
        if ($total > 500 * 1024 * 1024) throw new RuntimeException('Ukuran hasil extract terlalu besar.');
        if ($name === false || $name === '' || str_contains($name, "\0") ||
            str_starts_with($name, '/') || preg_match('#^[A-Za-z]:#', $name) ||
            preg_match('#(^|/)\.\.(/|$)#', str_replace('\\','/',$name))) {
            throw new RuntimeException('Paket ZIP memiliki path tidak aman.');
        }
    }
    if (!$zip->extractTo($target)) throw new RuntimeException('Gagal extract paket update.');
    $zip->close();
}
function find_project_dir($dir) {
    if (is_file($dir . '/VERSION.txt')) return $dir;
    $items = glob($dir . '/*', GLOB_ONLYDIR);
    if (count($items) === 1 && is_file($items[0] . '/VERSION.txt')) return $items[0];
    throw new RuntimeException('VERSION.txt tidak ditemukan pada paket update.');
}
function copy_tree($from, $to, $exclude=[]) {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $item) {
        $src = $item->getPathname();
        $rel = substr($src, strlen($from)+1);
        $relNorm = str_replace('\\','/',$rel);
        foreach ($exclude as $x) {
            if ($relNorm === $x || str_starts_with($relNorm, rtrim($x,'/') . '/')) continue 2;
        }
        $dst = $to . '/' . $rel;
        if ($item->isDir()) {
            if (!is_dir($dst)) mkdir($dst, 0775, true);
        } else {
            if (!is_dir(dirname($dst))) mkdir(dirname($dst), 0775, true);
            if (!copy($src,$dst)) throw new RuntimeException('Gagal menyalin: '.$relNorm);
        }
    }
}
function create_backup($root, $backupDir) {
    $name='before_update_'.date('Ymd_His').'.zip';
    $file=$backupDir.'/'.$name;
    $zip=new ZipArchive();
    if ($zip->open($file, ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true) throw new RuntimeException('Gagal membuat backup.');
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY);
    foreach ($it as $item) {
        $path=$item->getPathname(); $rel=substr($path,strlen($root)+1);
        $n=str_replace('\\','/',$rel);
        if (str_starts_with($n,'storage/backups/') || str_starts_with($n,'storage/update_uploads/') || str_starts_with($n,'storage/update_staging/')) continue;
        $zip->addFile($path,$rel);
    }
    $zip->close();
    return $file;
}
function csrf_input() {
    return '<input type="hidden" name="csrf" value="'.htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8').'">';
}

$message=''; $error=''; $details=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        check_csrf();
        if (isset($_POST['upload_update'])) {
            if (!isset($_FILES['update_zip']) || $_FILES['update_zip']['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Pilih file ZIP update yang valid.');
            $f=$_FILES['update_zip'];
            if ($f['size'] > 200*1024*1024) throw new RuntimeException('Ukuran ZIP maksimal 200 MB.');
            $tmpInfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $tmpInfo->file($f['tmp_name']);
            $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
            if ($ext !== 'zip' || !in_array($mime,['application/zip','application/x-zip-compressed','application/octet-stream'],true)) throw new RuntimeException('File harus berupa ZIP.');
            $id=bin2hex(random_bytes(8));
            $stored=$uploadDir.'/update_'.$id.'.zip';
            if (!move_uploaded_file($f['tmp_name'],$stored)) throw new RuntimeException('Gagal menyimpan file upload.');
            $stage=$stagingRoot.'/'.$id; mkdir($stage,0775,true);
            safe_zip_extract($stored,$stage);
            $pkg=find_project_dir($stage);
            $new=trim((string)file_get_contents($pkg.'/VERSION.txt'));
            if (!preg_match('/^\d+\.\d+\.\d+$/',$new)) throw new RuntimeException('Format VERSION.txt tidak valid.');
            if (version_compare($new, APP_VERSION, '<=')) throw new RuntimeException('Versi paket ('.$new.') harus lebih baru dari versi aplikasi ('.APP_VERSION.').');
            $backup=create_backup($root,$backupDir);
            $exclude=['config/database.php','storage','uploads','schema.sql','VERSION.txt'];
            copy_tree($pkg,$root,$exclude);
            // version marker is updated only after file copy succeeded
            file_put_contents($root.'/VERSION.txt',$new.PHP_EOL,LOCK_EX);
            $message='Update berhasil diinstal ke versi '.$new.'.';
            $details=['Backup: '.basename($backup),'Paket: '.basename($stored),'Versi baru: '.$new];
            rrmdir($stage);
        }
    } catch (Throwable $e) {
        $error=$e->getMessage();
    }
}
$current = is_file($root.'/VERSION.txt') ? trim(file_get_contents($root.'/VERSION.txt')) : APP_VERSION;
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Update Sistem</title><link rel="stylesheet" href="assets/admin-ui.css"></head><body>
<div class="admin-layout">
<aside class="admin-sidebar"><div class="admin-brand">☑ &nbsp; Ujian Online</div>
<div class="admin-section">MENU UTAMA</div><nav class="admin-nav"><a href="index.php">⌂ &nbsp; Dashboard</a><a href="index.php">▤ &nbsp; Ujian</a><a href="participants.php">♙ &nbsp; Peserta</a><a href="templates.php">⇩ &nbsp; Template Import Soal</a></nav>
<div class="admin-section">SISTEM</div><nav class="admin-nav"><a class="active" href="update.php">☁ &nbsp; Update Sistem</a></nav></aside>
<main class="admin-main"><header class="admin-topbar"><h1>☰ &nbsp; Update Sistem</h1><div><b>Administrator</b></div></header><div class="admin-content">
<h2 class="page-title">Update Sistem</h2><p class="page-subtitle">Kelola pembaruan aplikasi dengan aman dari file ZIP.</p>
<div class="ui-alert info"><b>ℹ Update aplikasi Ujian Online dari file ZIP.</b><br>Paket harus memiliki VERSION.txt dengan versi lebih baru.</div>
<?php if($message): ?><div class="ui-alert success"><b>✓ <?=htmlspecialchars($message)?></b><ul><?php foreach($details as $d): ?><li><?=htmlspecialchars($d)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if($error): ?><div class="ui-alert error"><b>⚠ Update gagal:</b> <?=htmlspecialchars($error)?></div><?php endif;?>
<div class="ui-grid ui-grid-4">
<div class="ui-card ui-stat"><div class="ui-label">Versi Saat Ini</div><div class="ui-value"><?=htmlspecialchars($current)?></div><span class="ui-badge">Terpasang</span></div>
<div class="ui-card ui-stat"><div class="ui-label">Versi Terbaru</div><div class="ui-value">—</div><span class="ui-badge gray">Pilih ZIP</span></div>
<div class="ui-card ui-stat"><div class="ui-label">Sumber Update</div><div class="ui-value" style="font-size:20px">☁ File ZIP</div><span class="ui-label">Upload manual</span></div>
<div class="ui-card ui-stat"><div class="ui-label">Status Sistem</div><div class="ui-value">🛡</div><span class="ui-badge">Aman</span></div></div>
<div class="ui-grid ui-grid-2" style="margin-top:18px">
<section class="ui-card"><h3>Update dari File ZIP</h3><div class="ui-alert info"><b>Backup otomatis</b><br>Backup aplikasi dibuat sebelum pemasangan file baru.</div>
<form method="post" enctype="multipart/form-data"><?=csrf_input()?><input type="hidden" name="upload_update" value="1">
<label class="ui-label">Pilih paket update</label><input id="update_zip" type="file" name="update_zip" accept=".zip,application/zip" required style="display:block;width:100%;margin:10px 0;padding:14px;border:1px dashed #aab7c7;border-radius:8px" onchange="showFile(this)">
<p id="fileName" class="page-subtitle">Maks. ukuran file: 200 MB</p>
<button class="ui-btn" type="submit" onclick="return confirm('Backup akan dibuat sebelum update. Lanjutkan?')">☁ Upload & Install Update</button></form>
<div class="ui-alert info" style="margin-bottom:0"><b>Syarat File Update</b><ul><li>Format ZIP</li><li>Memiliki VERSION.txt</li><li>Versi lebih baru</li><li>Maksimum 200 MB</li></ul></div></section>
<section><div class="ui-card"><h3>Panduan Update</h3><ol style="line-height:1.9;font-size:13px"><li>Siapkan file ZIP versi terbaru.</li><li>Pastikan ZIP memiliki VERSION.txt.</li><li>Pilih file melalui form.</li><li>Sistem memvalidasi file dan versi.</li><li>Backup otomatis dibuat.</li><li>File update dipasang dan versi diperbarui.</li></ol><div class="ui-alert info">Jangan menutup halaman selama proses update berlangsung.</div></div>
<div class="ui-card" style="margin-top:18px"><h3>Riwayat Update</h3><table class="ui-table"><tr><th>Versi</th><th>Status</th></tr><tr><td><?=htmlspecialchars($current)?></td><td><span class="ui-badge">Aktif</span></td></tr></table></div></section></div>
</div><div class="admin-footer">© <?=date('Y')?> Ujian Online · Versi <?=htmlspecialchars($current)?></div></main></div>
<script>function showFile(i){document.getElementById('fileName').textContent=i.files&&i.files[0]?'Dipilih: '+i.files[0].name:'Maks. ukuran file: 200 MB'}</script></body></html>