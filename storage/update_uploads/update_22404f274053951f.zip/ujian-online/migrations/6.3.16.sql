-- Ujian Online V6.3.16: Stabilization & Security baseline.
CREATE TABLE IF NOT EXISTS app_migrations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  version VARCHAR(50) NOT NULL UNIQUE,
  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO app_migrations(version) VALUES ('6.3.16');
