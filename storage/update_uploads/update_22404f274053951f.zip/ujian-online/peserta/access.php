<?php
declare(strict_types=1);
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
require __DIR__.'/../config.php';

$token=trim((string)($_GET['exam']??$_POST['exam']??''));
$email=strtolower(trim((string)($_POST['email']??'')));
if($token==='')exit('Link ujian tidak lengkap.');
$stmt=db()->prepare('SELECT * FROM exams WHERE public_token=? AND active=1 LIMIT 1');
$stmt->execute([$token]);$exam=$stmt->fetch();
if(!$exam)exit('Link ujian tidak valid atau ujian sudah tidak aktif.');

function send_verification(string $email,string $verifyUrl): bool {
    $subject='Verifikasi email - REVOPRINTSHOP';
    $body="Halo,\n\nKlik link berikut untuk memverifikasi email dan masuk ke ujian:\n\n{$verifyUrl}\n\nLink berlaku 30 menit.\n\nREVOPRINTSHOP";
    $headers="From: REVOPRINTSHOP <no-reply@".($_SERVER['HTTP_HOST']??'localhost').">\r\n";
    return @mail($email,$subject,$body,$headers);
}
function local_verify_url(string $token): string {
    $scheme=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
    $host=$_SERVER['HTTP_HOST']??'localhost';
    $base=rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])),'/\\');
    return $scheme.'://'.$host.$base.'/peserta/verify.php?token='.rawurlencode($token);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    check_csrf();
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))$error='Masukkan alamat email yang valid.';
    else{
        $pdo=db();
        $u=$pdo->prepare('SELECT * FROM users WHERE email=? OR username=? LIMIT 1');$u->execute([$email,$email]);$user=$u->fetch();
        if($user && ($user['role']??'participant')!=='participant')$error='Email ini terdaftar sebagai akun admin.';
        else{
            if(!$user){
                $username=$email;$hash=password_hash(bin2hex(random_bytes(24)),PASSWORD_DEFAULT);
                $ins=$pdo->prepare('INSERT INTO users(username,email,password_hash,full_name,role,email_verified_at) VALUES(?,?,?,?,?,NULL)');
                $ins->execute([$username,$email,$hash,$email,'participant']);$uid=(int)$pdo->lastInsertId();
            }else{$uid=(int)$user['id'];}
            $verifyToken=bin2hex(random_bytes(32));
            $upd=$pdo->prepare('UPDATE users SET email=?,email_verify_token=?,email_verify_expires_at=DATE_ADD(NOW(),INTERVAL 30 MINUTE) WHERE id=?');
            $upd->execute([$email,$verifyToken,$uid]);
            $url=local_verify_url($verifyToken).'&exam='.rawurlencode($token);
            $sent=send_verification($email,$url);
            $_SESSION['pending_verify_email']=$email;
            $_SESSION['pending_verify_exam']=$token;
            $message='Link verifikasi sudah dikirim ke '.$email.'.';
            if(!$sent && in_array($_SERVER['HTTP_HOST']??'', ['localhost','127.0.0.1','::1'], true)){
                $message='Localhost: mail() belum aktif. Untuk pengujian lokal, gunakan link verifikasi berikut.';
                $debugUrl=$url;
            }elseif(!$sent){$error='Email verifikasi tidak dapat dikirim. Pastikan layanan email hosting sudah aktif.';}
        }
    }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Verifikasi Email - REVOPRINTSHOP</title><style>body{margin:0;background:#f4f7fb;font-family:Inter,Arial;color:#101828}.wrap{max-width:620px;margin:60px auto;padding:20px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:18px;padding:30px;box-shadow:0 8px 28px #10182812}h1{margin:0 0 8px}p{color:#667085}label{font-weight:700;display:block;margin:22px 0 7px}input{width:100%;box-sizing:border-box;padding:13px;border:1px solid #d0d5dd;border-radius:10px;font-size:16px}button{margin-top:16px;background:#175cd3;color:#fff;border:0;border-radius:10px;padding:13px 18px;font-weight:800;cursor:pointer}.err{background:#fef3f2;color:#b42318;padding:12px;border-radius:10px;margin:15px 0}.ok{background:#ecfdf3;color:#027a48;padding:12px;border-radius:10px;margin:15px 0}.debug{word-break:break-all;background:#fff8ed;padding:12px;border-radius:10px}</style></head><body><div class="wrap"><div class="card"><h1>Test Psikotest Revo Print Shop</h1><p><b><?=htmlspecialchars($exam['title'])?></b></p><?php if(!empty($error)): ?><div class="err"><?=htmlspecialchars($error)?></div><?php endif; ?><?php if(!empty($message)): ?><div class="ok"><?=htmlspecialchars($message)?></div><?php if(!empty($debugUrl)): ?><div class="debug"><b>Link verifikasi lokal:</b><br><a href="<?=htmlspecialchars($debugUrl)?>"><?=htmlspecialchars($debugUrl)?></a></div><?php endif; ?><p>Setelah email diverifikasi, peserta dapat langsung mengerjakan ujian.</p><?php else: ?><p>Masukkan email. Sistem akan mengirim link verifikasi ke email tersebut.</p><form method="post">
<input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="exam" value="<?=htmlspecialchars($token)?>"><label>Email peserta</label><input type="email" name="email" required autocomplete="email" placeholder="nama@contoh.com"><button type="submit">Kirim Verifikasi</button></form><?php endif; ?></div></div></body></html>
