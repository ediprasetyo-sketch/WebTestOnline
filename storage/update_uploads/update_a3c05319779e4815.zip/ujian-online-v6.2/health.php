<?php
require __DIR__.'/config.php';
header('Content-Type: text/plain; charset=utf-8');

$base = '/';
if (function_exists('app_base')) {
    $base = app_base();
} else {
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $projectRoot = realpath(__DIR__) ?: __DIR__;
    $docRoot = str_replace('\\','/',rtrim($docRoot,'/\\'));
    $projectRoot = str_replace('\\','/',$projectRoot);
    if ($docRoot !== '' && str_starts_with($projectRoot,$docRoot)) {
        $base = str_replace('//','/',substr($projectRoot,strlen($docRoot)));
        if ($base === '') $base='/';
    }
}

echo "ExamFlow V6.3.1 OK\n";
echo "Project base: ".$base."\n";
echo "PHP: ".PHP_VERSION."\n";
try { db()->query('SELECT 1'); echo "MySQL: OK\n"; }
catch (Throwable $e) { echo "MySQL: ERROR - ". $e->getMessage() ."\n"; }
