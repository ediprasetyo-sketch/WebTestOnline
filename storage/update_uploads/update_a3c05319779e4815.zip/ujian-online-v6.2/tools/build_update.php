<?php
// CLI helper: php tools/build_update.php 6.3.1
// Creates an update package from the application tree, excluding runtime data/config.
declare(strict_types=1);
$version=$argv[1]??'';
if($version==='') exit("Usage: php tools/build_update.php 6.3.1\n");
$root=realpath(__DIR__.'/..');
$out=$root.'/releases/ujian-online-v'.$version.'-update.zip';
$zip=new ZipArchive(); $zip->open($out,ZipArchive::CREATE|ZipArchive::OVERWRITE);
$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
foreach($it as $f){
  $p=$f->getPathname();
  $rel=substr($p,strlen($root)+1);
  if(str_starts_with($rel,'storage/')||str_starts_with($rel,'uploads/')||$rel==='config.php'||str_starts_with($rel,'releases/')) continue;
  if(str_ends_with($rel,'.zip')) continue;
  $zip->addFile($p,$rel);
}
$zip->close();
echo $out.PHP_EOL;
