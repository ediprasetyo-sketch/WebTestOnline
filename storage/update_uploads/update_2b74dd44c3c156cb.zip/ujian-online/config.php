<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const DB_HOST = '127.0.0.1';
const DB_NAME = 'ujian_online';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );

        $pdo->exec("SET time_zone = '+07:00'");
    }
    return $pdo;
}

function app_base_path(): string {
    $script = str_replace('\\\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $pos = strpos($script, '/admin/');
    if ($pos === false) $pos = strpos($script, '/peserta/');
    if ($pos === false) {
        $dir = str_replace('\\\\', '/', dirname($script));
        return ($dir === '/' || $dir === '.' || $dir === '\\\\') ? '' : rtrim($dir, '/');
    }
    return substr($script, 0, $pos);
}

function app_url(string $path=''): string {
    return app_base_path() . '/' . ltrim($path, '/');
}


/**
 * Participant session is intentionally separate from the administrator session.
 * This lets an administrator test a public exam link without replacing the admin login.
 */
function participant_session(): ?array {
    $p = $_SESSION['participant'] ?? null;
    return is_array($p) && !empty($p['id']) && ($p['role'] ?? '') === 'participant' ? $p : null;
}

function require_participant(): array {
    $p = participant_session();
    if (!$p) {
        json_response(['error' => 'Unauthorized participant'], 401);
    }
    return $p;
}

function participant_logout_url(): string {
    return app_url('peserta/logout.php');
}

function require_login(string $role): void {
    if (empty($_SESSION['user']) || ($_SESSION['user']['role'] ?? null) !== $role) {
        header('Location: ' . app_url('login.php'));
        exit;
    }
}

function json_response(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}


/**
 * Single source of truth for application version.
 */
function app_version(): string {
    static $version = null;
    if ($version !== null) return $version;
    $file = __DIR__ . '/VERSION.txt';
    $raw = is_file($file) ? trim((string)file_get_contents($file)) : '';
    $version = preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9._-]+)?$/', $raw) ? $raw : '0.0.0';
    return $version;
}

/**
 * Apply SQL migrations once. Safe to call repeatedly.
 * Each migration is identified by filename and SHA-256 checksum.
 */
function ensure_migrations(): array {
    static $done = false;
    if ($done) return [];
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS schema_migrations (
        version VARCHAR(64) PRIMARY KEY,
        checksum CHAR(64) NOT NULL,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $dir = __DIR__ . '/migrations';
    if (!is_dir($dir)) { $done = true; return []; }
    $files = glob($dir . '/*.sql') ?: [];
    usort($files, 'strnatcasecmp');
    $applied = [];
    foreach ($files as $file) {
        $version = basename($file, '.sql');
        $sql = trim((string)file_get_contents($file));
        $checksum = hash('sha256', $sql);
        $st = $pdo->prepare("SELECT checksum FROM schema_migrations WHERE version=?");
        $st->execute([$version]);
        $old = $st->fetchColumn();
        if ($old !== false) {
            if (!hash_equals((string)$old, $checksum)) {
                throw new RuntimeException("Migration checksum berubah: {$version}");
            }
            continue;
        }
        if ($sql !== '') {
            $pdo->beginTransaction();
            try {
                // Migration files in this project contain normal SQL statements.
                foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) as $statement) {
                    $statement = trim($statement);
                    if ($statement !== '') $pdo->exec($statement);
                }
                $pdo->prepare("INSERT INTO schema_migrations(version, checksum) VALUES(?,?)")
                    ->execute([$version, $checksum]);
                $pdo->commit();
                $applied[] = $version;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
        }
    }
    $done = true;
    return $applied;
}


/**
 * Synchronize active attempts with their effective deadline.
 * Effective deadline = the earlier of started_at + duration_seconds and exam end_at.
 * Safe to call repeatedly from admin pages and monitoring polling.
 */
function sync_attempt_statuses(?PDO $pdo=null, ?int $examId=null): int {
    $pdo ??= db();

    $where = "a.status='active' AND a.started_at IS NOT NULL";
    $params = [];
    if ($examId !== null && $examId > 0) {
        $where .= " AND a.exam_id=?";
        $params[] = $examId;
    }

    $deadlineExpr = "LEAST(DATE_ADD(a.started_at, INTERVAL e.duration_seconds SECOND), e.end_at)";

    // Repair/normalize legacy deadline values first.
    $repair = $pdo->prepare(
        "UPDATE attempts a
         JOIN exams e ON e.id=a.exam_id
         SET a.deadline_at={$deadlineExpr}
         WHERE {$where} AND (a.deadline_at IS NULL OR a.deadline_at <> {$deadlineExpr})"
    );
    $repair->execute($params);

    // Expire attempts that have reached the effective deadline.
    $expire = $pdo->prepare(
        "UPDATE attempts a
         JOIN exams e ON e.id=a.exam_id
         SET a.status='expired',
             a.submitted_at=COALESCE(a.submitted_at, {$deadlineExpr}),
             a.deadline_at={$deadlineExpr}
         WHERE {$where} AND {$deadlineExpr} <= NOW()"
    );
    $expire->execute($params);

    return $expire->rowCount();
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('CSRF token tidak valid');
    }
}
