<?php
declare(strict_types=1);
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
require __DIR__.'/../config.php';
$token=trim((string)($_GET['token']??''));$examToken=trim((string)($_GET['exam']??''));
if($token==='')exit('Token verifikasi tidak lengkap.');
$s=db()->prepare('SELECT * FROM users WHERE email_verify_token=? AND email_verify_expires_at>=NOW() LIMIT 1');$s->execute([$token]);$u=$s->fetch();
if(!$u)exit('Link verifikasi tidak valid atau sudah kedaluwarsa. Silakan minta link baru.');
$pdo=db();$pdo->prepare('UPDATE users SET email_verified_at=NOW(),email_verify_token=NULL,email_verify_expires_at=NULL WHERE id=?')->execute([(int)$u['id']]);
$examToken=$examToken?:($_SESSION['pending_verify_exam']??'');
session_regenerate_id(true);
$_SESSION['participant']=['id'=>(int)$u['id'],'username'=>$u['username'],'email'=>$u['email'],'full_name'=>$u['full_name'],'role'=>'participant'];
if($examToken!=='')$_SESSION['public_exam_token']=$examToken;
unset($_SESSION['pending_verify_email'],$_SESSION['pending_verify_exam']);
header('Location: index.php?exam='.rawurlencode($examToken));exit;
