<?php
declare(strict_types=1);
require __DIR__.'/../config.php';
require_login('admin');

$id=(int)($_GET['id']??0);
$stmt=db()->prepare('SELECT * FROM questions WHERE id=? LIMIT 1');
$stmt->execute([$id]);
$q=$stmt->fetch();
if(!$q) exit('Soal tidak ditemukan.');
$examId=(int)$q['exam_id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
  check_csrf();
  $type=$_POST['type']??'mcq';
  $text=trim((string)($_POST['question_text']??''));
  $correct=trim((string)($_POST['correct_option']??'')) ?: null;
  $points=(float)($_POST['points']??1);
$essayKey=trim((string)($_POST['essay_answer_key']??'')) ?: null;
  if($text==='') exit('Pertanyaan wajib diisi.');
  if(!in_array($type,['mcq','essay'],true)) $type='mcq';
  if($type==='mcq' && !in_array($correct,['A','B','C','D'],true)) exit('Kunci jawaban PG harus A-D.');
  if($type==='essay') $correct=null;

  $imagePath=$q['question_image']??null;
  if(isset($_POST['remove_image']) && $_POST['remove_image']==='1'){
    if($imagePath && is_file(__DIR__.'/../'.$imagePath)) @unlink(__DIR__.'/../'.$imagePath);
    $imagePath=null;
  }
  if(!empty($_FILES['question_image']['tmp_name'])){
    $f=$_FILES['question_image'];
    if($f['error']!==UPLOAD_ERR_OK) exit('Upload gambar gagal.');
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if(!isset($allowed[$mime])) exit('Format gambar harus JPG, PNG, WEBP, atau GIF.');
    if($f['size']>5*1024*1024) exit('Ukuran gambar maksimal 5 MB.');
    $dir=__DIR__.'/../uploads/questions';
    if(!is_dir($dir)) mkdir($dir,0755,true);
    $filename='q_'.bin2hex(random_bytes(12)).'.'.$allowed[$mime];
    if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$filename)) exit('Gagal menyimpan gambar.');
    if($imagePath && is_file(__DIR__.'/../'.$imagePath)) @unlink(__DIR__.'/../'.$imagePath);
    $imagePath='uploads/questions/'.$filename;
  }

  $upd=db()->prepare('UPDATE questions SET type=?, question_text=?, question_image=?, essay_answer_key=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=?, points=? WHERE id=?');
  $upd->execute([$type,$text,$imagePath,$type==='essay'?$essayKey:null,$_POST['A']??null,$_POST['B']??null,$_POST['C']??null,$_POST['D']??null,$correct,$points,$id]);
  header('Location: questions.php?id='.$examId.'&updated=1'); exit;
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Edit Soal</title>
<style>body{margin:0;background:#f5f7fb;font-family:Arial;color:#17202a}.wrap{max-width:850px;margin:30px auto;padding:0 18px}.card{background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:24px;box-shadow:0 4px 18px #1018280d}input,select,textarea{width:100%;box-sizing:border-box;padding:11px;margin:6px 0 14px;border:1px solid #d0d5dd;border-radius:9px;font:inherit}textarea{min-height:140px}button,a.btn{display:inline-block;padding:11px 16px;border:0;border-radius:9px;background:#175cd3;color:#fff;font-weight:700;text-decoration:none;cursor:pointer}.secondary{background:#667085!important}.danger{background:#b42318!important}.preview{max-width:100%;max-height:380px;border:1px solid #e4e7ec;border-radius:12px;display:block;margin:10px 0 15px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap"><div class="card">
<h1>Edit Soal</h1>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
<label>Jenis</label><select name="type"><option value="mcq" <?=$q['type']==='mcq'?'selected':''?>>Pilihan ganda</option><option value="essay" <?=$q['type']==='essay'?'selected':''?>>Essay</option></select>
<label>Pertanyaan</label><textarea name="question_text" required><?=htmlspecialchars($q['question_text'])?></textarea>
<label>Gambar soal</label>
<?php if(!empty($q['question_image'])): ?><img class="preview" src="<?=htmlspecialchars(app_url($q['question_image']))?>" alt="Gambar soal"><label><input type="checkbox" name="remove_image" value="1" style="width:auto"> Hapus gambar saat menyimpan</label><?php endif; ?>
<input type="file" name="question_image" accept="image/jpeg,image/png,image/webp,image/gif">
<div class="grid"><input name="A" placeholder="Pilihan A" value="<?=htmlspecialchars((string)$q['option_a'])?>"><input name="B" placeholder="Pilihan B" value="<?=htmlspecialchars((string)$q['option_b'])?>"><input name="C" placeholder="Pilihan C" value="<?=htmlspecialchars((string)$q['option_c'])?>"><input name="D" placeholder="Pilihan D" value="<?=htmlspecialchars((string)$q['option_d'])?>"></div>
<label>Jawaban acuan / kunci essay (opsional)</label><textarea name="essay_answer_key" placeholder="Jawaban yang diharapkan untuk membantu penilaian essay"><?=htmlspecialchars((string)($q['essay_answer_key']??''))?></textarea>
<label>Kunci jawaban<select name="correct_option"><option value="">Untuk essay kosongkan</option><?php foreach(['A','B','C','D'] as $o): ?><option <?=$q['correct_option']===$o?'selected':''?>><?=$o?></option><?php endforeach; ?></select>
<label>Poin</label><input name="points" type="number" step="0.5" min="0" value="<?=htmlspecialchars((string)$q['points'])?>">
<button type="submit">Simpan Perubahan</button> <a class="btn secondary" href="questions.php?id=<?=$examId?>">Batal</a>
</form></div></div></body></html>
