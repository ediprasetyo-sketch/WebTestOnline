<?php
declare(strict_types=1);
require __DIR__.'/../config.php';
require_login('admin');

$pdo = db();
$exams = $pdo->query("
    SELECT e.*,
      (SELECT COUNT(*) FROM questions q WHERE q.exam_id=e.id) AS question_count,
      (SELECT COUNT(*) FROM attempts a WHERE a.exam_id=e.id) AS participant_count
    FROM exams e
    ORDER BY e.id DESC
")->fetchAll();

$totalExams = count($exams);
$activeExams = 0;
$totalQuestions = 0;
$totalAttempts = 0;
foreach ($exams as $e) {
    $activeExams += (int)$e['active'];
    $totalQuestions += (int)$e['question_count'];
    $totalAttempts += (int)$e['participant_count'];
}

$recentAttempts = [];
try {
    $recentAttempts = $pdo->query("
        SELECT a.id, a.started_at, a.status, e.title
        FROM attempts a
        JOIN exams e ON e.id=a.exam_id
        ORDER BY a.id DESC
        LIMIT 6
    ")->fetchAll();
} catch (Throwable $ignore) {
    $recentAttempts = [];
}

$msg = $_GET['msg'] ?? '';
$err = $_GET['err'] ?? '';

function dt_input(?string $v): string {
    return $v ? date('Y-m-d\TH:i', strtotime($v)) : '';
}
function exam_status(array $e): array {
    $now = time();
    $start = strtotime((string)$e['start_at']);
    $end = strtotime((string)$e['end_at']);
    if (!(int)$e['active']) return ['Nonaktif', 'off'];
    if ($now < $start) return ['Terjadwal', 'scheduled'];
    if ($now > $end) return ['Selesai', 'done'];
    return ['Aktif', 'on'];
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>REVOPRINTSHOP · Administrator</title>
<style>
:root{
 --bg:#f4f7fb;--card:#fff;--ink:#101828;--muted:#667085;--line:#e4e7ec;
 --navy:#0b1324;--navy2:#121c31;--blue:#175cd3;--blue2:#0b4abf;
 --green:#027a48;--orange:#b54708;--red:#b42318;--purple:#6941c6;
 --shadow:0 10px 30px rgba(16,24,40,.07)
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,Segoe UI,Arial,sans-serif}
a{color:inherit}
.layout{min-height:100vh;display:grid;grid-template-columns:240px 1fr}
.sidebar{background:linear-gradient(180deg,var(--navy),#101a2e);color:#fff;padding:22px 14px;position:sticky;top:0;height:100vh}
.brand{padding:4px 12px 24px;border-bottom:1px solid #ffffff14}
.brand-name{font-size:21px;font-weight:900;letter-spacing:-.04em}
.brand-sub{margin-top:5px;font-size:11px;color:#aab5c8;text-transform:uppercase;letter-spacing:.08em}
.nav{padding-top:18px;display:grid;gap:6px}
.nav a{display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:10px;text-decoration:none;color:#cbd5e1;font-size:14px;font-weight:700}
.nav a:hover,.nav a.active{background:#ffffff12;color:#fff}
.nav .icon{width:24px;text-align:center;opacity:.9}
.side-bottom{position:absolute;left:14px;right:14px;bottom:18px;padding:12px;border:1px solid #ffffff12;border-radius:12px;background:#ffffff08;font-size:12px;color:#aab5c8}
.main{min-width:0}
.topbar{height:70px;background:#fff;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;padding:0 32px;position:sticky;top:0;z-index:5}
.top-title{font-weight:900}.top-user{color:var(--muted);font-size:13px}.top-user a{color:var(--red);text-decoration:none;font-weight:800}
.content{max-width:1500px;margin:auto;padding:30px 32px 48px}
.hero{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:24px}
.hero h1{margin:0;font-size:31px;letter-spacing:-.04em}
.hero p{margin:7px 0 0;color:var(--muted)}
.actions{display:flex;gap:9px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 14px;border:0;border-radius:9px;background:var(--blue);color:#fff;text-decoration:none;font-weight:800;font-size:13px;cursor:pointer}
.btn:hover{background:var(--blue2)}
.btn.secondary{background:#eef2f7;color:#344054}.btn.secondary:hover{background:#e4e7ec}
.btn.danger{background:var(--red)}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:22px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:15px;padding:18px;box-shadow:var(--shadow);position:relative;overflow:hidden}
.stat:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--blue)}
.stat.green:before{background:var(--green)}.stat.orange:before{background:var(--orange)}.stat.purple:before{background:var(--purple)}
.stat-label{font-size:12px;color:var(--muted);font-weight:800;text-transform:uppercase;letter-spacing:.05em}
.stat-num{font-size:30px;font-weight:900;margin-top:5px}.stat-help{font-size:12px;color:var(--muted);margin-top:3px}
.grid2{display:grid;grid-template-columns:1.65fr .85fr;gap:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px;box-shadow:var(--shadow);margin-bottom:18px}
.card-head{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-bottom:17px}
.card-head h2{margin:0;font-size:19px}.card-head p{margin:4px 0 0;color:var(--muted);font-size:13px}
.table-wrap{overflow:auto}
table{width:100%;border-collapse:collapse;min-width:900px}
th,td{padding:12px 9px;text-align:left;border-bottom:1px solid var(--line);vertical-align:middle}
th{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
td{font-size:13px}
.muted{color:var(--muted)}.hint{font-size:11px;color:var(--muted);margin-top:4px}
.status{display:inline-flex;padding:5px 9px;border-radius:99px;font-size:11px;font-weight:800}
.status.on{background:#ecfdf3;color:var(--green)}
.status.scheduled{background:#eff8ff;color:#175cd3}
.status.done{background:#f2f4f7;color:#475467}
.status.off{background:#fef3f2;color:var(--red)}
.mini{display:flex;gap:5px;flex-wrap:wrap}.mini .btn{padding:7px 9px;font-size:11px}
.formgrid{display:grid;grid-template-columns:1fr 1fr;gap:13px 16px}
label{display:block;font-size:12px;font-weight:800;margin-bottom:6px}
input,select{width:100%;padding:11px 12px;border:1px solid #d0d5dd;border-radius:9px;background:#fff;font:inherit;outline:none}
input:focus,select:focus{border-color:var(--blue);box-shadow:0 0 0 3px #175cd31a}
.notice{padding:11px 13px;border-radius:10px;margin:10px 0;font-size:13px}.ok{background:#ecfdf3;color:var(--green)}.warn{background:#fff4ed;color:var(--orange)}
.quick{display:grid;gap:9px}.quick a{display:flex;align-items:center;justify-content:space-between;padding:13px;border:1px solid var(--line);border-radius:11px;text-decoration:none;font-weight:800;font-size:13px}.quick a:hover{background:#f8fafc}
.activity{display:grid;gap:0}.activity-item{display:flex;gap:10px;padding:12px 0;border-bottom:1px solid var(--line)}.activity-item:last-child{border-bottom:0}
.dot{width:9px;height:9px;border-radius:50%;background:var(--blue);margin-top:5px;flex:0 0 auto}
.activity-title{font-size:13px;font-weight:800}.activity-meta{font-size:11px;color:var(--muted);margin-top:3px}
.empty{padding:24px 8px;text-align:center;color:var(--muted);font-size:13px}
@media(max-width:1050px){.layout{grid-template-columns:78px 1fr}.brand-name,.brand-sub,.nav a span.label,.side-bottom{display:none}.brand{padding:4px 7px 24px}.nav a{justify-content:center}.content{padding:24px}.grid2{grid-template-columns:1fr}}
@media(max-width:760px){.stats{grid-template-columns:1fr 1fr}.hero{align-items:flex-start;flex-direction:column}.topbar{padding:0 18px}.content{padding:20px 15px}.formgrid{grid-template-columns:1fr}}
@media(max-width:480px){.layout{display:block}.sidebar{height:auto;position:relative;padding:12px}.brand{border:0;padding:5px 8px}.brand-name,.brand-sub{display:block}.nav{display:flex;overflow:auto;padding:7px 0 0}.nav a{white-space:nowrap;justify-content:flex-start}.nav a span.label{display:inline}.side-bottom{display:none}.topbar{height:58px}.stats{grid-template-columns:1fr}.hero h1{font-size:25px}}
</style>
</head>
<body>
<div class="layout">
<aside class="sidebar">
  <div class="brand">
    <div class="brand-name">REVOPRINTSHOP</div>
    <div class="brand-sub">Administrator · V6.3.11</div>
  </div>
  <nav class="nav">
    <a class="active" href="index.php"><span class="icon">⌂</span><span class="label">Dashboard</span></a>
    <a href="#ujian"><span class="icon">▣</span><span class="label">Ujian</span></a>
    <a href="participants.php"><span class="icon">♙</span><span class="label">Peserta</span></a>
    <a href="#aktivitas"><span class="icon">◷</span><span class="label">Aktivitas</span></a>
    <a href="update.php"><span class="icon">↻</span><span class="label">Update Sistem</span></a>
  </nav>
  <div class="side-bottom">Panel administrator<br><b>REVOPRINTSHOP</b></div>
</aside>

<main class="main">
<header class="topbar">
  <div class="top-title">Dashboard Administrator</div>
  <div class="top-user"><b><?=htmlspecialchars($_SESSION['user']['full_name']??'Administrator')?></b> · <a href="../logout.php">Keluar</a></div>
</header>

<section class="content">
  <div class="hero">
    <div>
      <h1>Selamat datang di REVOPRINTSHOP</h1>
      <p>Kelola ujian online, soal, peserta, dan hasil dalam satu dashboard.</p>
    </div>
    <div class="actions">
      <a class="btn" href="#buat-ujian">+ Buat Ujian</a>
      <a class="btn secondary" href="participants.php">Kelola Peserta</a>
    </div>
  </div>

  <div class="stats">
    <div class="stat"><div class="stat-label">Total ujian</div><div class="stat-num"><?=$totalExams?></div><div class="stat-help">Semua ujian tersimpan</div></div>
    <div class="stat green"><div class="stat-label">Ujian aktif</div><div class="stat-num"><?=$activeExams?></div><div class="stat-help">Status aktif di sistem</div></div>
    <div class="stat orange"><div class="stat-label">Total soal</div><div class="stat-num"><?=$totalQuestions?></div><div class="stat-help">Pilihan ganda dan essay</div></div>
    <div class="stat purple"><div class="stat-label">Peserta / attempt</div><div class="stat-num"><?=$totalAttempts?></div><div class="stat-help">Riwayat pengerjaan</div></div>
  </div>

  <?php if($msg): ?><div class="notice ok"><?=htmlspecialchars($msg)?></div><?php endif; ?>
  <?php if($err): ?><div class="notice warn"><?=htmlspecialchars($err)?></div><?php endif; ?>

  <div class="grid2">
    <div>
      <section class="card" id="buat-ujian">
        <div class="card-head">
          <div><h2>Buat Ujian Baru</h2><p>Setelah dibuat, Anda akan langsung masuk ke Kelola Soal.</p></div>
        </div>
        <form method="post" action="create_exam.php">
          <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>">
          <div class="formgrid">
            <div><label>Judul ujian</label><input name="title" placeholder="Contoh: Test Psikotest Revo Print Shop" required></div>
            <div><label>Durasi (menit)</label><input name="duration" type="number" min="1" max="1440" value="30" required></div>
            <div><label>Mulai</label><input name="start_at" type="datetime-local" value="<?=dt_input(date('Y-m-d H:i:s'))?>" required></div>
            <div><label>Selesai</label><input name="end_at" type="datetime-local" value="<?=dt_input(date('Y-m-d H:i:s',time()+86400))?>" required></div>
            <div><label>Tampilan soal</label><select name="question_mode"><option value="all">Semua sekaligus</option><option value="one_by_one">Satu per satu</option></select></div>
            <div><label>Status</label><select name="active"><option value="1">Aktif</option><option value="0">Nonaktif</option></select></div>
            <div><label>Randomisasi soal</label><select name="randomize_questions"><option value="0">Soal normal</option><option value="1">Acak soal</option></select></div>
            <div><label>Randomisasi pilihan</label><select name="randomize_options"><option value="0">Normal</option><option value="1">Acak A-D</option></select></div>
          </div>
          <div style="margin-top:17px"><button class="btn" type="submit">+ Buat Ujian</button></div>
        </form>
      </section>

      <section class="card" id="ujian">
        <div class="card-head">
          <div><h2>Daftar Ujian</h2><p><?=$totalExams?> ujian tersimpan · link publik muncul setelah soal tersedia</p></div>
        </div>
        <div class="table-wrap">
        <table>
          <thead><tr><th>Ujian</th><th>Jadwal</th><th>Durasi</th><th>Soal</th><th>Peserta</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
          <?php foreach($exams as $e): [$statusLabel,$statusClass]=exam_status($e); ?>
          <tr>
            <td><b><?=htmlspecialchars($e['title'])?></b><?php if(!empty($e['public_token'])):?><div class="hint">Link publik tersedia</div><?php endif;?></td>
            <td><?=htmlspecialchars($e['start_at'])?><br><span class="muted">sampai <?=htmlspecialchars($e['end_at'])?></span></td>
            <td><?=floor((int)$e['duration_seconds']/60)?> menit</td>
            <td><b><?=intval($e['question_count'])?></b></td>
            <td><?=intval($e['participant_count'])?></td>
            <td><span class="status <?=$statusClass?>"><?=$statusLabel?></span></td>
            <td><div class="mini">
              <a class="btn" href="edit_exam.php?id=<?=$e['id']?>">Edit</a>
              <a class="btn secondary" href="questions.php?id=<?=$e['id']?>">Soal</a>
              <a class="btn secondary" href="results.php?id=<?=$e['id']?>">Hasil</a>
              <a class="btn secondary" href="preview.php?id=<?=$e['id']?>" target="_blank">Preview</a>
              <?php if((int)$e['question_count']>0): ?>
                <a class="btn" href="exam_link.php?id=<?=$e['id']?>">Bagikan</a>
              <?php else: ?>
                <span class="btn secondary" style="opacity:.5;cursor:not-allowed">Bagikan</span>
              <?php endif; ?>
            </div></td>
          </tr>
          <?php endforeach; ?>
          <?php if(!$exams): ?><tr><td colspan="7"><div class="empty">Belum ada ujian. Buat ujian pertama Anda dari tombol di atas.</div></td></tr><?php endif; ?>
          </tbody>
        </table>
        </div>
      </section>
    </div>

    <div>
      <section class="card">
        <div class="card-head"><div><h2>Akses Cepat</h2><p>Menu yang paling sering digunakan.</p></div></div>
        <div class="quick">
          <a href="#buat-ujian"><span>+ Buat ujian baru</span><span>→</span></a>
          <a href="participants.php"><span>Kelola peserta</span><span>→</span></a>
          <a href="#ujian"><span>Kelola soal</span><span>→</span></a>
          <a href="#ujian"><span>Lihat hasil</span><span>→</span></a>
          <a href="update.php"><span>Update sistem</span><span>→</span></a>
        </div>
      </section>

      <section class="card" id="aktivitas">
        <div class="card-head"><div><h2>Aktivitas Terbaru</h2><p>Pengerjaan ujian terakhir yang tercatat.</p></div></div>
        <?php if($recentAttempts): ?>
        <div class="activity">
          <?php foreach($recentAttempts as $a): ?>
          <div class="activity-item">
            <div class="dot"></div>
            <div><div class="activity-title"><?=htmlspecialchars($a['title'])?></div><div class="activity-meta"><?=htmlspecialchars($a['started_at'])?> · <?=htmlspecialchars($a['status'])?></div></div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?><div class="empty">Belum ada aktivitas pengerjaan.</div><?php endif; ?>
      </section>

      <section class="card">
        <div class="card-head"><div><h2>Alur Kerja</h2><p>Urutan yang disarankan saat membuat ujian.</p></div></div>
        <div class="quick">
          <a href="#buat-ujian"><span>1. Buat ujian</span><span>✓</span></a>
          <a href="#ujian"><span>2. Isi & edit soal</span><span>✓</span></a>
          <a href="#ujian"><span>3. Bagikan link</span><span>✓</span></a>
          <a href="#ujian"><span>4. Pantau hasil</span><span>✓</span></a>
        </div>
      </section>
    </div>
  </div>
</section>
</main>
</div>
</body>
</html>
