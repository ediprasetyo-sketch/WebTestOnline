<?php
declare(strict_types=1);
require __DIR__.'/../config.php';
require_login('admin');

$id=(int)($_GET['id']??0);
$stmt=db()->prepare("SELECT * FROM exams WHERE id=?");
$stmt->execute([$id]);
$exam=$stmt->fetch();
if(!$exam) exit('Ujian tidak ditemukan.');

$qs=db()->prepare("SELECT * FROM questions WHERE exam_id=? ORDER BY sort_order,id");
$qs->execute([$id]);
$questions=$qs->fetchAll();

function question_image_url(?string $path): string {
    if(!$path) return '';
    $path=trim($path);
    if($path==='') return '';
    if(preg_match('~^https?://~i',$path)) return $path;
    $path=ltrim(str_replace('\\','/',$path),'/');
    // The admin page is one directory below the project root.
    return '../'.$path;
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Soal — <?=htmlspecialchars($exam['title'])?></title>
<style>
:root{--bg:#f4f7fb;--card:#fff;--ink:#101828;--muted:#667085;--line:#e4e7ec;--blue:#175cd3;--red:#b42318;--green:#027a48}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Inter,Arial,sans-serif;color:var(--ink)}
.top{background:#101828;color:#fff;padding:16px 0}.wrap{max-width:1180px;margin:auto;padding:0 22px}.nav{display:flex;justify-content:space-between;align-items:center}.brand{font-weight:800;font-size:19px}.back{color:#d0d5dd;text-decoration:none}
.hero{padding:26px 0 12px}.hero h1{margin:0 0 6px;font-size:30px}.muted{color:var(--muted)}
.grid{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:18px}.card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:20px;box-shadow:0 4px 18px #1018280a}
h2{margin:0 0 14px;font-size:19px}label{font-size:13px;font-weight:700;display:block;margin-top:10px}
input,select,textarea{width:100%;padding:11px;border:1px solid #d0d5dd;border-radius:9px;margin:5px 0 10px;font:inherit}textarea{min-height:120px;resize:vertical}
button,.btn{display:inline-block;padding:10px 14px;border:0;border-radius:9px;background:var(--blue);color:#fff;font-weight:700;text-decoration:none;cursor:pointer}
.btn.secondary{background:#667085}.btn.danger{background:var(--red)}.btn.light{background:#eef4ff;color:#175cd3}
.q{border:1px solid var(--line);border-radius:14px;padding:16px;margin:12px 0;background:#fff}.qhead{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.badge{display:inline-block;padding:4px 8px;border-radius:99px;background:#ecfdf3;color:var(--green);font-size:12px;font-weight:700}
.qtext{white-space:pre-wrap;line-height:1.55;margin:10px 0}.qimg{display:block;max-width:100%;max-height:360px;object-fit:contain;border:1px solid var(--line);border-radius:10px;background:#fff;margin:12px 0}.opts{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:10px 0}.opt{padding:9px;background:#f8fafc;border-radius:8px}.actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:12px}
.alert{padding:11px 13px;border-radius:10px;margin:12px 0;background:#ecfdf3;color:#027a48}.empty{padding:25px;text-align:center;color:var(--muted)}
.import{background:#eef4ff;border:1px dashed #84a9ff;padding:14px;border-radius:12px}.small{font-size:12px;color:var(--muted)}
@media(max-width:900px){.grid{grid-template-columns:1fr}.opts{grid-template-columns:1fr}.qhead{flex-direction:column}}
</style></head><body>
<div class="top"><div class="wrap nav"><div class="brand">REVOPRINTSHOP</div><a class="back" href="index.php">← Dashboard</a></div></div>
<div class="wrap hero"><div style="display:flex;justify-content:space-between;align-items:flex-end;gap:15px;flex-wrap:wrap">
<div><h1><?=htmlspecialchars($exam['title'])?></h1><div class="muted"><?=count($questions)?> soal · Kelola, edit, hapus, upload gambar, atau import soal.</div></div>
<div style="display:flex;gap:8px;flex-wrap:wrap">
<a class="btn light" href="preview.php?id=<?=$id?>" target="_blank">👁 Preview Ujian</a>
<?php if(count($questions)>0): ?><a class="btn" href="exam_link.php?id=<?=$id?>">Bagikan Link</a><?php else: ?><span class="btn secondary" style="opacity:.55;cursor:not-allowed">Bagikan Link</span><?php endif; ?>
</div></div></div>
<div class="wrap grid">
<main>
<?php if(isset($_GET['created'])): ?><div class="alert">Ujian berhasil dibuat. Silakan isi soal terlebih dahulu.</div><?php endif; ?><?php if(isset($_GET['need_questions'])): ?><div class="alert">Tambahkan minimal satu soal sebelum membagikan link.</div><?php endif; ?><?php if(isset($_GET['updated'])): ?><div class="alert">Soal berhasil diperbarui.</div><?php endif; ?>
<?php if(isset($_GET['deleted'])): ?><div class="alert">Soal berhasil dihapus.</div><?php endif; ?>
<?php if(isset($_GET['imported'])): ?><div class="alert"><?=htmlspecialchars((string)$_GET['imported'])?> soal berhasil diimport.</div><?php endif; ?>
<h2>Daftar Soal</h2>
<?php if(!$questions): ?><div class="card empty">Belum ada soal. Tambahkan soal di panel sebelah kanan.</div><?php endif; ?>
<?php foreach($questions as $i=>$q): $img=question_image_url($q['question_image']??null); ?>
<div class="q">
  <div class="qhead"><div><b>Soal <?=($i+1)?></b> <span class="badge"><?=($q['type']==='essay'?'Essay':'Pilihan Ganda')?></span></div><span class="small">Poin: <?=htmlspecialchars((string)$q['points'])?></span></div>
  <div class="qtext"><?=htmlspecialchars($q['question_text'])?></div>
  <?php if($img): ?><img class="qimg" src="<?=htmlspecialchars($img)?>" alt="Gambar soal" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="small" style="display:none">Gambar tidak dapat dimuat. Periksa file di uploads/questions.</div><?php endif; ?>
  <?php if($q['type']!=='essay'): ?><div class="opts">
    <div class="opt"><b>A.</b> <?=htmlspecialchars((string)$q['option_a'])?></div>
    <div class="opt"><b>B.</b> <?=htmlspecialchars((string)$q['option_b'])?></div>
    <div class="opt"><b>C.</b> <?=htmlspecialchars((string)$q['option_c'])?></div>
    <div class="opt"><b>D.</b> <?=htmlspecialchars((string)$q['option_d'])?></div>
  </div><div class="small">Kunci: <b><?=htmlspecialchars((string)$q['correct_option'])?></b></div><?php else: ?><?php if(!empty($q['essay_answer_key'])): ?><div class="small"><b>Jawaban acuan:</b> <?=htmlspecialchars((string)$q['essay_answer_key'])?></div><?php endif; ?><?php endif; ?>
  <div class="actions">
    <a class="btn light" href="edit_question.php?id=<?=$q['id']?>">Edit</a>
    <form method="post" action="delete_question.php" style="display:inline" onsubmit="return confirm('Hapus soal ini? Jawaban yang terkait soal ini pada attempt akan ikut dihapus.');">
      <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="id" value="<?=$q['id']?>">
      <button class="btn danger" type="submit">Hapus</button>
    </form>
  </div>
</div>
<?php endforeach; ?>
</main>
<aside>
<div class="card"><h2>Tambah Soal</h2>
<form method="post" action="save_question.php" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="exam_id" value="<?=$id?>">
<label>Jenis</label><select name="type" id="type"><option value="mcq">Pilihan ganda</option><option value="essay">Essay</option></select>
<label>Pertanyaan</label><textarea name="question_text" required placeholder="Tulis pertanyaan..."></textarea>
<label>Gambar soal</label><input type="file" name="question_image" accept="image/jpeg,image/png,image/webp,image/gif">
<div class="small">JPG, PNG, WEBP, GIF · maksimal 5 MB.</div>
<div id="essayFields" style="display:none"><label>Jawaban acuan / kunci essay</label><textarea name="essay_answer_key" placeholder="Jawaban yang diharapkan untuk membantu penilaian"></textarea></div><div id="mcqFields">
<label>Pilihan A</label><input name="A">
<label>Pilihan B</label><input name="B">
<label>Pilihan C</label><input name="C">
<label>Pilihan D</label><input name="D">
<label>Kunci</label><select name="correct_option"><option value="">Pilih kunci</option><option>A</option><option>B</option><option>C</option><option>D</option></select>
</div>
<label>Poin</label><input name="points" type="number" min="0" step="0.5" value="1">
<button type="submit">Simpan Soal</button>
</form></div>
<div class="card"><h2>Import Massal</h2><div class="import"><p>Import CSV/XLS/XLSX untuk teks dan pilihan jawaban.</p><a href="templates.php">Download template</a>
<form method="post" action="import_questions.php" enctype="multipart/form-data" style="margin-top:12px">
<input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token())?>"><input type="hidden" name="exam_id" value="<?=$id?>">
<input type="file" name="file" accept=".csv,.txt,.xls,.xlsx" required><button type="submit">Import Soal</button>
</form></div></div>
</aside>
</div>
<script>
const type=document.getElementById('type'), fields=document.getElementById('mcqFields');
const essayFields=document.getElementById('essayFields');function toggle(){fields.style.display=type.value==='essay'?'none':'block';essayFields.style.display=type.value==='essay'?'block':'none';}
type.addEventListener('change',toggle);toggle();
</script></body></html>
