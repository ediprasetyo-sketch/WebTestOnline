<?php
declare(strict_types=1);
session_start();
require __DIR__.'/../config.php';
require_once __DIR__.'/../includes/participant_session.php';

$token=trim((string)($_GET['exam']??''));
if($token!==''){
  $stmt=db()->prepare('SELECT * FROM exams WHERE public_token=? AND active=1 LIMIT 1');
  $stmt->execute([$token]);$publicExam=$stmt->fetch();
  if(!$publicExam)exit('Link ujian tidak valid atau ujian sudah tidak aktif.');
  if(participant_session()===null||($_SESSION['public_exam_token']??'')!==$token){
    header('Location: access.php?exam='.rawurlencode($token));exit;
  }
  $exams=[$publicExam];
}else{
  if(participant_session()===null){header('Location: ' . app_url('login.php'));exit;}
  $exams=db()->query("SELECT * FROM exams WHERE active=1 ORDER BY start_at")->fetchAll();
}
$appTitle='REVOPRINTSHOP';
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($appTitle)?></title>
<style>
:root{--blue:#175cd3;--ink:#17202a;--muted:#667085;--line:#e4e7ec}*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial;background:#f5f7fb;color:var(--ink);font-size:16px}.top{background:#101828;color:#fff;padding:18px}.wrap{max-width:1000px;margin:auto;padding:24px}.brand{font-weight:800;font-size:20px}.top a{color:#fff}.card{border:1px solid var(--line);background:#fff;padding:22px;border-radius:14px;margin:14px 0;box-shadow:0 4px 16px #10182808}.timer{position:sticky;top:8px;background:#17202a;color:#fff;padding:16px;border-radius:10px;font-size:26px;font-weight:800;display:flex;justify-content:space-between;z-index:5}.q{border:1px solid #ddd;padding:18px;margin:14px 0;border-radius:10px}.opt{display:block;margin:12px 0;font-size:17px}.opt input{transform:scale(1.15);margin-right:8px}.hidden{display:none}.danger{background:#b42318!important}.qimg{display:block;width:auto;max-width:100%;max-height:420px;margin:14px 0;border-radius:12px;border:1px solid #e4e7ec;object-fit:contain;background:#fff}.imgerr{color:#b42318;background:#fef3f2;padding:10px;border-radius:8px}.qtext{margin-bottom:12px;font-size:18px;line-height:1.55}.qnum{font-weight:800;margin-right:4px}textarea.answerbox{width:100%;min-height:190px;padding:14px;font:17px/1.55 Inter,Arial,sans-serif;border:1px solid #98a2b3;border-radius:10px;resize:vertical}button{padding:11px 16px;background:#175cd3;color:#fff;border:0;border-radius:8px;font-size:16px;font-weight:800;cursor:pointer}button:disabled{opacity:.6;cursor:not-allowed}.saved{font-size:13px;color:#027a48;margin-top:6px}.loading{opacity:.7}

.examhead{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;border-bottom:1px solid #e4e7ec;padding-bottom:14px;margin-bottom:14px}.eyebrow{font-size:12px;font-weight:800;color:#667085;letter-spacing:.08em}.progress{font-weight:800;background:#eef4ff;color:#175cd3;padding:9px 12px;border-radius:999px}.qtop{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.points{white-space:nowrap;background:#ecfdf3;color:#027a48;padding:7px 10px;border-radius:8px;font-weight:800;font-size:14px}.answerlabel{display:block;font-weight:800;margin:10px 0 7px}.navrow{display:flex;align-items:center;gap:10px;margin-top:18px}.navrow .saved{flex:1}.secondary{background:#667085}.submit{background:#027a48}.smallsave{min-height:18px}@media(max-width:650px){.examhead,.qtop{flex-direction:column}.navrow{flex-wrap:wrap}.navrow .saved{flex-basis:100%;order:-1}.points{align-self:flex-start}}
</style></head><body>
<div class="top"><div class="wrap" style="padding:0"><span class="brand"><?=htmlspecialchars($appTitle)?></span><span style="float:right"><?=htmlspecialchars(($_SESSION['participant']['full_name']??$_SESSION['participant']['email']??''))?> · <a href="logout.php">Keluar Peserta</a></span></div></div>
<div class="wrap"><div id="list"><h1>Ujian Online</h1><?php foreach($exams as $e): ?><div class="card"><h2><?=htmlspecialchars($e['title'])?></h2><p>Peserta: <b><?=htmlspecialchars(($_SESSION['participant']['full_name']??''))?></b><br><span style="color:#667085;font-size:14px"><?=htmlspecialchars(($_SESSION['participant']['email']??''))?></span></p><p>Durasi <?=floor($e['duration_seconds']/60)?> menit · <?=htmlspecialchars($e['start_at'])?> sampai <?=htmlspecialchars($e['end_at'])?></p><button onclick="startExam(<?=$e['id']?>)">Mulai / Lanjutkan</button></div><?php endforeach; ?></div>
<div id="exam" class="hidden">
  <div id="timerBox" class="timer"><span>Waktu tersisa</span><span id="timer">--:--</span></div>
  <div class="card">
    <div class="examhead"><div><div class="eyebrow">UJIAN ONLINE</div><h1 id="title"></h1></div><div id="progress" class="progress">Soal 0 / 0</div></div>
    <div id="questions"></div>
    <div class="navrow">
      <button id="prevBtn" class="secondary" onclick="goQuestion(-1)">← Sebelumnya</button>
      <span id="saveStatus" class="saved"></span>
      <button id="nextBtn" onclick="goQuestion(1)">Berikutnya →</button>
      <button id="submitBtn" class="submit" onclick="submitExam(false)">Kirim Ujian</button>
    </div>
  </div>
</div></div>
<script>
const csrf=<?=json_encode(csrf_token())?>;
let attempt=null,deadline=0,clockOffset=0,interval=null,examId=null,submitting=false,currentIndex=0,questions=[];
const pending=new Map(),timers=new Map();
async function api(url,opt={}){opt.headers={...(opt.headers||{}),'X-CSRF-Token':csrf,'Content-Type':'application/json'};const r=await fetch(url,opt);const d=await r.json().catch(()=>({error:'Respons server tidak valid'}));if(!r.ok)throw Error(d.error||'Gagal');return d}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function imageHtml(path){if(!path)return '';let p=String(path).replace(/\\/g,'/').trim();if(!p)return '';if(!/^https?:\/\//i.test(p)){p=p.replace(/^\/+/, '');p='../'+p}return `<div><img class="qimg" src="${esc(p)}" alt="Gambar soal" loading="eager" onerror="this.style.display='none';this.parentElement.querySelector('.imgerr').style.display='block'"><div class="imgerr" style="display:none">Gambar soal tidak dapat dimuat.</div></div>`}
function syncClock(ms){if(typeof ms==='number')clockOffset=ms-Date.now()}
function nowServerMs(){return Date.now()+clockOffset}
function queueSave(qid,opt,essay,immediate=false){if(timers.has(qid))clearTimeout(timers.get(qid));const run=()=>saveNow(qid,opt,essay);if(immediate)run();else timers.set(qid,setTimeout(run,350))}
function saveNow(qid,opt,essay){const p=(async()=>{try{const d=await api('../api/save_answer.php',{method:'POST',body:JSON.stringify({attempt_id:attempt,question_id:qid,selected_option:opt,essay_answer:essay})});syncClock(d.server_now_ms);deadline=d.deadline_ms;document.getElementById('saveStatus').textContent='Jawaban tersimpan';return d}catch(e){document.getElementById('saveStatus').textContent='Gagal menyimpan';console.warn(e);throw e}})();pending.set(qid,p);p.finally(()=>{if(pending.get(qid)===p)pending.delete(qid)});return p}
async function flushSaves(){for(const t of timers.values())clearTimeout(t);timers.clear();if(pending.size)await Promise.allSettled([...pending.values()])}
function renderQuestion(){const q=questions[currentIndex];if(!q)return;const heading=`<div class="qtop"><div class="qtext"><span class="qnum">${currentIndex+1}.</span>${esc(q.question_text)}</div><span class="points">${esc(q.points??0)} poin</span></div>`;let body='';if(q.type==='essay'){body=`${imageHtml(q.question_image)}<label class="answerlabel">Jawaban Anda</label><textarea class="answerbox" data-q="${q.id}" oninput="questionChanged(this)">${esc(q.saved_essay_answer||'')}</textarea><div class="saved smallsave">${q.saved_essay_answer?'Tersimpan':''}</div>`}else{const saved=q.saved_display_option||'';body=`${imageHtml(q.question_image)}${['A','B','C','D'].map(k=>`<label class="opt"><input type="radio" name="current_q" value="${k}" ${saved===k?'checked':''} onchange="selectOption('${k}')"><b>${k}.</b> ${esc(q['option_'+k.toLowerCase()])}</label>`).join('')}<div class="saved smallsave">${saved?'Tersimpan':''}</div>`}document.getElementById('questions').innerHTML=`<div class="q">${heading}${body}</div>`;document.getElementById('progress').textContent=`Soal ${currentIndex+1} / ${questions.length}`;document.getElementById('prevBtn').disabled=currentIndex===0;document.getElementById('nextBtn').classList.toggle('hidden',currentIndex===questions.length-1);document.getElementById('submitBtn').classList.toggle('hidden',currentIndex!==questions.length-1);}
function currentQ(){return questions[currentIndex]}
function selectOption(k){const q=currentQ();q.saved_display_option=k;document.getElementById('saveStatus').textContent='Menyimpan...';queueSave(q.id,k,'',true)}
function questionChanged(el){const q=currentQ();q.saved_essay_answer=el.value;document.getElementById('saveStatus').textContent='Menyimpan...';queueSave(q.id,null,el.value,false)}
async function goQuestion(delta){await flushSaves();const next=currentIndex+delta;if(next<0||next>=questions.length)return;currentIndex=next;renderQuestion();window.scrollTo({top:0,behavior:'smooth'})}
async function startExam(id){try{examId=id;const d=await api('../api/start.php',{method:'POST',body:JSON.stringify({exam_id:id})});attempt=d.attempt_id;deadline=d.deadline_ms;syncClock(d.server_now_ms);const e=await api('../api/exam.php?id='+encodeURIComponent(id)+'&attempt_id='+encodeURIComponent(attempt));questions=e.questions||[];document.getElementById('title').textContent=e.title;if(!questions.length){alert('Belum ada soal pada ujian ini.');return}currentIndex=0;renderQuestion();document.getElementById('list').classList.add('hidden');document.getElementById('exam').classList.remove('hidden');tick();clearInterval(interval);interval=setInterval(tick,250)}catch(e){alert(e.message)}}
async function tick(){const left=Math.max(0,deadline-nowServerMs());const s=Math.ceil(left/1000),min=Math.floor(s/60);document.getElementById('timer').textContent=String(min).padStart(2,'0')+':'+String(s%60).padStart(2,'0');if(s<=60)document.getElementById('timerBox').classList.add('danger');if(left<=0){clearInterval(interval);await submitExam(true)}}
async function submitExam(auto){if(submitting)return;submitting=true;document.getElementById('submitBtn').disabled=true;try{await flushSaves();const d=await api('../api/submit.php',{method:'POST',body:JSON.stringify({attempt_id:attempt})});clearInterval(interval);alert(auto?'Waktu habis. Jawaban yang sudah tersimpan dikumpulkan.':'Ujian dikirim. Nilai: '+d.score);location.href='?exam='+encodeURIComponent(<?=json_encode($token)?>)}catch(e){submitting=false;document.getElementById('submitBtn').disabled=false;alert(e.message)}}
</script></body></html>
