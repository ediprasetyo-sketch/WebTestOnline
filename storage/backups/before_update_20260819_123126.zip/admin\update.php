<?php
require_once __DIR__ . '/../config.php';
require_login('admin');

const APP_VERSION = '6.3.18';
$root = realpath(__DIR__ . '/..');
$backupDir = $root . '/storage/backups';
$uploadDir = $root . '/storage/update_uploads';
$stagingRoot = $root . '/storage/update_staging';
@mkdir($backupDir, 0775, true);
@mkdir($uploadDir, 0775, true);
@mkdir($stagingRoot, 0775, true);

function rrmdir($dir) {
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
    @rmdir($dir);
}
function safe_zip_extract($zipFile, $target) {
    $zip = new ZipArchive();
    if ($zip->open($zipFile) !== true) throw new RuntimeException('File ZIP tidak dapat dibuka.');
    if ($zip->numFiles > 5000) throw new RuntimeException('Paket update terlalu banyak file.');
    $total = 0;
    for ($i=0; $i<$zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        $stat = $zip->statIndex($i);
        $total += (int)($stat['size'] ?? 0);
        if ($total > 500 * 1024 * 1024) throw new RuntimeException('Ukuran hasil extract terlalu besar.');
        if ($name === false || $name === '' || str_contains($name, "\0") ||
            str_starts_with($name, '/') || preg_match('#^[A-Za-z]:#', $name) ||
            preg_match('#(^|/)\.\.(/|$)#', str_replace('\\','/',$name))) {
            throw new RuntimeException('Paket ZIP memiliki path tidak aman.');
        }
    }
    if (!$zip->extractTo($target)) throw new RuntimeException('Gagal extract paket update.');
    $zip->close();
}
function find_project_dir($dir) {
    if (is_file($dir . '/VERSION.txt')) return $dir;
    $items = glob($dir . '/*', GLOB_ONLYDIR);
    if (count($items) === 1 && is_file($items[0] . '/VERSION.txt')) return $items[0];
    throw new RuntimeException('VERSION.txt tidak ditemukan pada paket update.');
}
function copy_tree($from, $to, $exclude=[]) {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $item) {
        $src = $item->getPathname();
        $rel = substr($src, strlen($from)+1);
        $relNorm = str_replace('\\','/',$rel);
        foreach ($exclude as $x) {
            if ($relNorm === $x || str_starts_with($relNorm, rtrim($x,'/') . '/')) continue 2;
        }
        $dst = $to . '/' . $rel;
        if ($item->isDir()) {
            if (!is_dir($dst)) mkdir($dst, 0775, true);
        } else {
            if (!is_dir(dirname($dst))) mkdir(dirname($dst), 0775, true);
            if (!copy($src,$dst)) throw new RuntimeException('Gagal menyalin: '.$relNorm);
        }
    }
}
function create_backup($root, $backupDir) {
    $name='before_update_'.date('Ymd_His').'.zip';
    $file=$backupDir.'/'.$name;
    $zip=new ZipArchive();
    if ($zip->open($file, ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true) throw new RuntimeException('Gagal membuat backup.');
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY);
    foreach ($it as $item) {
        $path=$item->getPathname(); $rel=substr($path,strlen($root)+1);
        $n=str_replace('\\','/',$rel);
        if (str_starts_with($n,'storage/backups/') || str_starts_with($n,'storage/update_uploads/') || str_starts_with($n,'storage/update_staging/')) continue;
        $zip->addFile($path,$rel);
    }
    $zip->close();
    return $file;
}
function csrf_input() {
    return '<input type="hidden" name="csrf" value="'.htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8').'">';
}

$message=''; $error=''; $details=[];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        check_csrf();
        if (isset($_POST['upload_update'])) {
            if (!isset($_FILES['update_zip']) || $_FILES['update_zip']['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Pilih file ZIP update yang valid.');
            $f=$_FILES['update_zip'];
            if ($f['size'] > 200*1024*1024) throw new RuntimeException('Ukuran ZIP maksimal 200 MB.');
            $tmpInfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $tmpInfo->file($f['tmp_name']);
            $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
            if ($ext !== 'zip' || !in_array($mime,['application/zip','application/x-zip-compressed','application/octet-stream'],true)) throw new RuntimeException('File harus berupa ZIP.');
            $id=bin2hex(random_bytes(8));
            $stored=$uploadDir.'/update_'.$id.'.zip';
            if (!move_uploaded_file($f['tmp_name'],$stored)) throw new RuntimeException('Gagal menyimpan file upload.');
            $stage=$stagingRoot.'/'.$id; mkdir($stage,0775,true);
            safe_zip_extract($stored,$stage);
            $pkg=find_project_dir($stage);
            $new=trim((string)file_get_contents($pkg.'/VERSION.txt'));
            if (!preg_match('/^\d+\.\d+\.\d+$/',$new)) throw new RuntimeException('Format VERSION.txt tidak valid.');
            if (version_compare($new, APP_VERSION, '<=')) throw new RuntimeException('Versi paket ('.$new.') harus lebih baru dari versi aplikasi ('.APP_VERSION.').');
            $backup=create_backup($root,$backupDir);
            $exclude=['config/database.php','storage','uploads','schema.sql','VERSION.txt'];
            copy_tree($pkg,$root,$exclude);
            // version marker is updated only after file copy succeeded
            file_put_contents($root.'/VERSION.txt',$new.PHP_EOL,LOCK_EX);
            $message='Update berhasil diinstal ke versi '.$new.'.';
            $details=['Backup: '.basename($backup),'Paket: '.basename($stored),'Versi baru: '.$new];
            rrmdir($stage);
        }
    } catch (Throwable $e) {
        $error=$e->getMessage();
    }
}
$current = is_file($root.'/VERSION.txt') ? trim(file_get_contents($root.'/VERSION.txt')) : APP_VERSION;
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Update Sistem</title><style>
:root{--b:#2563eb;--nav:#152238;--bg:#f5f7fb;--line:#e4e8ef;--muted:#64748b}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:var(--bg);color:#1f2937}.side{position:fixed;width:240px;top:0;bottom:0;background:var(--nav);color:#d7e0ec}.brand{height:60px;background:#fff;color:#24549d;font-size:19px;font-weight:bold;padding:20px}.nav a{display:block;padding:13px 20px;color:#d7e0ec;text-decoration:none;font-size:14px}.nav a.active,.nav a:hover{background:#2459b8;color:#fff}.section{font-size:10px;color:#8492a7;padding:22px 18px 7px}.main{margin-left:240px}.top{height:60px;background:#fff;border-bottom:1px solid var(--line);padding:19px 24px;font-weight:bold}.content{padding:24px;max-width:1500px;margin:auto}.notice{margin:16px 0;background:#eaf3ff;border:1px solid #b7d2f5;border-radius:8px;padding:15px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px}.card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:20px}.stat{text-align:center}.label,.muted{font-size:12px;color:var(--muted)}.big{font-size:25px;font-weight:bold;margin:10px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.warning{background:#fff8e9;border:1px solid #f2d28d;border-radius:8px;padding:14px;margin-bottom:16px}.drop{border:2px dashed #a9b6c7;border-radius:10px;text-align:center;padding:35px;background:#fbfcfe}.file{display:none}.btn{display:inline-block;background:var(--b);color:#fff;border:0;border-radius:7px;padding:11px 18px;font-weight:bold;cursor:pointer;text-decoration:none}.req{margin-top:16px;background:#effbf3;border:1px solid #b4dfc1;border-radius:8px;padding:14px;font-size:13px}.steps{padding:0;margin:0;list-style:none}.steps li{display:flex;gap:10px;margin:13px 0;font-size:13px}.n{background:#2459a6;color:#fff;width:24px;height:24px;border-radius:50%;display:inline-grid;place-items:center;flex:0 0 auto}.ok,.err{padding:14px;border-radius:8px;margin-bottom:15px}.ok{background:#edf9f0;border:1px solid #b0dfbb}.err{background:#fff0f0;border:1px solid #efb7b7}.info{margin-top:16px;padding:12px;background:#eaf3ff;border:1px solid #a5c8ef;border-radius:7px;font-size:12px}.badge{padding:4px 8px;border-radius:6px;background:#e9f7ed;color:#18733b;font-size:12px}.footer{padding:22px;color:#64748b;font-size:12px}@media(max-width:950px){.side{display:none}.main{margin-left:0}.stats,.grid{grid-template-columns:1fr}}
</style></head><body><aside class="side"><div class="brand">☑ &nbsp; Ujian Online</div><div class="section">MENU UTAMA</div><nav class="nav"><a href="../index.php">⌂ &nbsp; Beranda</a><a href="dashboard.php">▣ &nbsp; Dashboard</a><a href="exams.php">▤ &nbsp; Ujian</a><a href="questions.php">▤ &nbsp; Soal</a><a href="participants.php">♙ &nbsp; Peserta</a><a href="results.php">▥ &nbsp; Hasil Ujian</a><a href="reports.php">▧ &nbsp; Laporan</a></nav><div class="section">SISTEM</div><nav class="nav"><a href="backup.php">▱ &nbsp; Backup & Restore</a><a class="active" href="update.php">☁ &nbsp; Update Sistem</a><a href="activity_log.php">☷ &nbsp; Log Aktivitas</a></nav></aside><main class="main"><div class="top">☰ &nbsp; Update Sistem</div><div class="content"><h2 style="margin:0">Update Sistem</h2><div class="notice"><b>ℹ Update aplikasi Ujian Online dari file ZIP.</b><br><span class="muted">Pilih paket update yang memiliki VERSION.txt dengan versi lebih baru.</span></div>
<?php if($message): ?><div class="ok"><b>✓ <?=htmlspecialchars($message)?></b><ul><?php foreach($details as $d): ?><li><?=htmlspecialchars($d)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if($error): ?><div class="err"><b>⚠ Update gagal:</b> <?=htmlspecialchars($error)?></div><?php endif;?>
<div class="stats"><div class="card stat"><div class="label">Versi Saat Ini</div><div class="big"><?=htmlspecialchars($current)?></div><span class="badge">Terpasang</span></div><div class="card stat"><div class="label">Versi Terbaru</div><div class="big">—</div><span class="muted">Pilih ZIP untuk update</span></div><div class="card stat"><div class="label">Sumber Update</div><div class="big" style="font-size:20px">☁ File ZIP</div><span class="muted">Upload manual</span></div><div class="card stat"><div class="label">Status Sistem</div><div class="big">🛡</div><span class="badge">Aman</span></div></div>
<div class="grid"><section class="card"><h3>Update dari File ZIP</h3><div class="warning"><b>⚠ Backup otomatis</b><br><span class="muted">Backup aplikasi dibuat sebelum pemasangan file baru.</span></div><form method="post" enctype="multipart/form-data"><?=csrf_input()?><input type="hidden" name="upload_update" value="1"><div class="drop"><div style="font-size:38px;color:#2563eb">☁↑</div><p><b>Drag & drop file ZIP di sini</b></p><p class="muted">atau</p><label class="btn" for="update_zip">Pilih File ZIP</label><input class="file" id="update_zip" type="file" name="update_zip" accept=".zip,application/zip" required onchange="showFile(this)"><p id="fileName" class="muted">Maks. ukuran file: 200 MB</p></div><div class="req"><b>✓ Syarat File Update</b><ul><li>Format file ZIP</li><li>Memiliki VERSION.txt</li><li>Versi lebih baru</li><li>Maksimum 200 MB</li></ul></div><p><button class="btn" type="submit" onclick="return confirm('Backup akan dibuat sebelum update. Lanjutkan?')">☁ Upload & Install Update</button></p></form></section>
<section><div class="card"><h3>Panduan Update</h3><ol class="steps"><li><span class="n">1</span>Siapkan file ZIP versi terbaru.</li><li><span class="n">2</span>Pastikan ZIP memiliki VERSION.txt.</li><li><span class="n">3</span>Pilih file ZIP melalui form.</li><li><span class="n">4</span>Sistem memvalidasi file dan versi.</li><li><span class="n">5</span>Sistem membuat backup otomatis.</li><li><span class="n">6</span>File update dipasang dan versi diperbarui.</li></ol><div class="info">ℹ Jangan menutup halaman selama proses update berlangsung.</div></div><div class="card" style="margin-top:18px"><h3>Riwayat Update</h3><p><b><?=htmlspecialchars($current)?></b> &nbsp; <span class="badge">Versi aktif</span></p><p class="muted">Riwayat detail dapat dikembangkan melalui log update.</p></div></section></div></div><div class="footer">© <?=date('Y')?> Ujian Online · Versi <?=htmlspecialchars($current)?></div></main><script>function showFile(i){document.getElementById('fileName').textContent=i.files&&i.files[0]?'Dipilih: '+i.files[0].name:'Maks. ukuran file: 200 MB'}</script></body></html>